﻿using System;
namespace assignment2
{
    public class ComputerShop
    {
        private Factory factory;

        public ComputerShop(Factory factory)
        {
            this.factory = factory;
        }

        public virtual Computer AssembleComputer()
        {
            return factory.CreateComputer();
        }
    }
}
