﻿using System;
namespace assignment2
{
    public class LowBudgetFactory : Factory
    {
        private IProcessor Processor { get; set; }
        private IHardDisk HardDisk { get; set; }
        private IMonitor Monitor { get; set; }

        public LowBudgetFactory()
        {
            Processor = new CheapProcessor();
            HardDisk = new CheapHardDisk();
            Monitor = new CheapMonitor();
        }

        public override Computer CreateComputer()
        {
            return new Computer(Processor, HardDisk, Monitor);
        }
    }
}
