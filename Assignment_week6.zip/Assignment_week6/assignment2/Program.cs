﻿using System;

namespace assignment2
{
    class Program
    {
        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        void Start()
        {
            Factory highBudgetFactory = new HighBudgetFactory();
            ComputerShop computerShop1 = new ComputerShop(highBudgetFactory);
            Console.WriteLine("[shop creating expensive computers]");
            Computer expensiveComputer = computerShop1.AssembleComputer();
            expensiveComputer.Test();

            Console.WriteLine();

            Factory lowBudgetFactory = new LowBudgetFactory();
            ComputerShop computerShop2 = new ComputerShop(lowBudgetFactory);
            Console.WriteLine("[shop creating cheap computers]");
            Computer cheapComputer = computerShop2.AssembleComputer();
            cheapComputer.Test();
        }
    }
}
