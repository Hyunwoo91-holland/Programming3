﻿using System;
namespace assignment2
{
    public class CheapMonitor : IMonitor
    {
        public CheapMonitor()
        {
        }

        public void Display()
        {
            Console.WriteLine("display stuff very poor...");
        }
    }
}
