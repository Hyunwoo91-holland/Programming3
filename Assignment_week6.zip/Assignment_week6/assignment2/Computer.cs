﻿using System;
namespace assignment2
{
    public class Computer
    {
        private IProcessor Processor { get; set; }
        private IHardDisk HardDisk { get; set; }
        private IMonitor Monitor { get; set; }

        public Computer(IProcessor processor, IHardDisk hardDisk, IMonitor monitor)
        {
            Processor = processor;
            HardDisk = hardDisk;
            Monitor = monitor;
        }

        public void Test()
        {
            Processor.PerformOperation();
            HardDisk.StoreData();
            Monitor.Display();
        }
    }
}
