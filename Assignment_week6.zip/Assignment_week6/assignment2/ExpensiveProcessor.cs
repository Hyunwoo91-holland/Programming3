﻿using System;
namespace assignment2
{
    public class ExpensiveProcessor : IProcessor
    {
        public ExpensiveProcessor()
        {
        }

        public void PerformOperation()
        {
            Console.WriteLine("performing operation very quickly...");
        }
    }
}
