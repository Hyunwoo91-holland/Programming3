﻿using System;
namespace assignment2
{
    public interface IHardDisk
    {
        void StoreData();
    }
}
