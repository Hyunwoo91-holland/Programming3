﻿using System;
namespace assignment2
{
    public class CheapProcessor : IProcessor
    {
        public CheapProcessor()
        {
        }

        public void PerformOperation()
        {
            Console.WriteLine("performing operation not so quickly...");
        }
    }
}
