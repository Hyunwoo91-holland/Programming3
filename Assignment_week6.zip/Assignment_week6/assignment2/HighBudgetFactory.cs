﻿using System;
namespace assignment2
{
    public class HighBudgetFactory : Factory
    {
        private IProcessor Processor { get; set; }
        private IHardDisk HardDisk { get; set; }
        private IMonitor Monitor { get; set; }

        public HighBudgetFactory()
        {
            Processor = new ExpensiveProcessor();
            HardDisk = new ExpensiveHardDisk();
            Monitor = new ExpensiveMonitor();
        }

        public override Computer CreateComputer()
        {
            return new Computer(Processor, HardDisk, Monitor);
        }
    }
}
