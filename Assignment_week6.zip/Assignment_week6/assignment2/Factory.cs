﻿using System;
namespace assignment2
{
    public class Factory
    {
        private IProcessor Processor { get; set; }
        private IHardDisk HardDisk { get; set; }
        private IMonitor Monitor { get; set; }

        public virtual Computer CreateComputer()
        {
            return new Computer(Processor,  HardDisk,  Monitor);
        }
    }
}
