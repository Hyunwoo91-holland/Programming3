﻿using System;
namespace assignment1
{
    public class LowBudgetShop : ComputerShop
    {
        Computer computer;
        IProcessor processor;
        IHardDisk hardDisk;
        IMonitor monitor;

        public LowBudgetShop()
        {
            processor = new CheapProcessor();
            hardDisk = new CheapHardDisk();
            monitor = new CheapMonitor();
        }

        public override Computer AssembleComputer()
        {
            computer = new Computer(processor, hardDisk, monitor);
            return computer;
        }
    }
}
