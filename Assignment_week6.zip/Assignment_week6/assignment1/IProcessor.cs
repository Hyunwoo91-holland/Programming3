﻿using System;
namespace assignment1
{
    public interface IProcessor
    {
        void PerformOperation();
    }
}
