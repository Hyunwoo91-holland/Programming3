﻿using System;
namespace assignment1
{
    public class ComputerShop
    {
        private IProcessor Processor { get; set; }
        private IHardDisk HardDisk { get; set; }
        private IMonitor Monitor { get; set; }

        public virtual Computer AssembleComputer()
        {
            return new Computer(Processor,  HardDisk,  Monitor);
        }
    }
}
