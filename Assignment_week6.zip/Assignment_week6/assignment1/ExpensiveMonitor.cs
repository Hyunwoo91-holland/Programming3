﻿using System;
namespace assignment1
{
    public class ExpensiveMonitor : IMonitor
    {
        public ExpensiveMonitor()
        {
        }

        public void Display()
        {
            Console.WriteLine("displaying stuff very nice...");
        }
    }
}
