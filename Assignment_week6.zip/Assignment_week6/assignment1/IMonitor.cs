﻿using System;
namespace assignment1
{
    public interface IMonitor
    {
        void Display();
    }
}
