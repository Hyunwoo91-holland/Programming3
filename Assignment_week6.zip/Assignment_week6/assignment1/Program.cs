﻿using System;

namespace assignment1
{
    class Program
    {
        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        void Start()
        {
            ComputerShop expensiveComputerShop = new HighBudgetShop();
            Console.WriteLine("[shop creating expensive computers]");
            Computer expensiveComputer = expensiveComputerShop.AssembleComputer();
            expensiveComputer.Test();
            Console.WriteLine();
            ComputerShop cheapComputerShop = new LowBudgetShop();
            Console.WriteLine("[shop creating cheap computers]");
            Computer cheapComputer = cheapComputerShop.AssembleComputer();
            cheapComputer.Test();
        }
    }
}
