﻿using System;
namespace assignment1
{
    public class CheapHardDisk : IHardDisk
    {
        public CheapHardDisk()
        {
        }

        public void StoreData()
        {
            Console.WriteLine("storing data not so quickly...");
        }
    }
}
