﻿using System;
namespace assignment1
{
    public class CheapMonitor : IMonitor
    {
        public CheapMonitor()
        {
        }

        public void Display()
        {
            Console.WriteLine("displaying stuff very poor...");
        }
    }
}
