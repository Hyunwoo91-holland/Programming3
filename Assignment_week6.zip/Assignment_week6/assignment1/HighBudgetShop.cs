﻿using System;
namespace assignment1
{
    public class HighBudgetShop : ComputerShop
    {
        Computer computer;
        IProcessor processor;
        IHardDisk hardDisk;
        IMonitor monitor;

        public HighBudgetShop()
        {
            processor = new ExpensiveProcessor();
            hardDisk = new ExpensiveHardDisk();
            monitor = new ExpensiveMonitor();
        }

        public override Computer AssembleComputer()
        {
            computer = new Computer(processor,  hardDisk,  monitor);
            return computer;
        }
    }
}
