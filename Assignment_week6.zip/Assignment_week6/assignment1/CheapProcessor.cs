﻿using System;
namespace assignment1
{
    public class CheapProcessor : IProcessor
    {
        public CheapProcessor()
        {
        }

        public void PerformOperation()
        {
            Console.WriteLine("performing operation not so quickly...");
        }
    }
}
