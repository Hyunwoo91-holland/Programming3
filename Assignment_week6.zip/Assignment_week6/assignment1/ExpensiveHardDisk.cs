﻿using System;
namespace assignment1
{
    public class ExpensiveHardDisk : IHardDisk
    {
        public ExpensiveHardDisk()
        {
        }

        public void StoreData()
        {
            Console.WriteLine("storing data very quickly...");
        }
    }
}
