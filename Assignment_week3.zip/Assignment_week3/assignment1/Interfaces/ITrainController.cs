﻿

namespace Controller
{
    public interface ITrainController
    {
        void Next();
    }
}
