﻿
namespace Interfaces
{
    public interface ITrainJourney
    {
        ITrainStation CurrentStation { get; }
        bool IsReturn { get; }

        void NextStation();

        void AddObserver(IStationObserver observer);
        void RemoveObserver(IStationObserver observer);
    }
}
