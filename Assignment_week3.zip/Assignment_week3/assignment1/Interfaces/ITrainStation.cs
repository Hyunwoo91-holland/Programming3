﻿using System;

namespace Interfaces
{
    public interface ITrainStation
    {

        public string Name { get; set; }
        public int ArrivalTrack { get; set; }
        public DateTime ArrivalTime { get; set; }
        public DateTime DepartureTime { get; set; }
    }
}
