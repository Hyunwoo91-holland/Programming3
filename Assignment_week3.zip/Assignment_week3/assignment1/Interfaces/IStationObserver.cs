﻿
namespace Interfaces
{
    public interface IStationObserver
    {
        void Update(ITrainStation trainStation);
    }
}
