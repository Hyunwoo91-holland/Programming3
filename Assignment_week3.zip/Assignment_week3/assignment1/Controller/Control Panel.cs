﻿using System;
using System.Windows.Forms;
using Model;
using Views;
using Interfaces;

namespace Controller
{
    public partial class ControlPanel : Form
    {
        private TrainJourney journey;
        private ITrainController controller;
        private TrainDisplay trainDisplay;
        private StationDisplay stationDisplay;

        private string Title { get; set; }
        private int Sequence { get; set; }

        public ControlPanel()
        {
            InitializeComponent();

            journey = new TrainJourney();
            controller = new TrainController(journey);
            trainDisplay = new TrainDisplay(journey);
            stationDisplay = new StationDisplay(journey);
            Sequence = 1;
        }

        private void btnNextStation_Click(object sender, EventArgs e)
        {
            controller.Next();
            Sequence++;

            Title = $"TrainDisplay #{Sequence}";
            trainDisplay.Text = Title;
            stationDisplay.Text = Title;
        }

        private void btnNewDisplay_Click(object sender, EventArgs e)
        {
            trainDisplay.Show();
        }

        private void btnRemainingStations_Click(object sender, EventArgs e)
        {
            stationDisplay.Show();
        }
    }
}
