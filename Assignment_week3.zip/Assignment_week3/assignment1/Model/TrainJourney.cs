﻿using System;
using System.Collections.Generic;
using Interfaces;

namespace Model
{
    public class TrainJourney : ITrainJourney
    {
        public List<TrainStation> trainStations = new List<TrainStation>
        {
            new TrainStation("Den Helder",3,new DateTime(2022, 4,27,11,34, 0),new DateTime(2022, 4,27,11,34,0)),
            new TrainStation("Den Helder Zuid",1,new DateTime(2022, 4,27,11,38,0),new DateTime(2022, 4,27,11,38,0)),
            new TrainStation("Anna Paulowna",1,new DateTime(2022, 4,27,11,44,0),new DateTime(2022, 4,27,11,45,0)),
            new TrainStation("Schagen",1,new DateTime(2022, 4,27,11,52,0),new DateTime(2022, 4,27,11,52,0)),
            new TrainStation("Heerhugowaard",1,new DateTime(2022, 4,27,12,01,0),new DateTime(2022, 4,27,12,01,0)),
            new TrainStation("Alkmaar Noord",1,new DateTime(2022, 4,27,12,07,0),new DateTime(2022, 4,27,12,07,0)),
            new TrainStation("Alkmaar",5,new DateTime(2022, 4,27,12,11,0),new DateTime(2022, 4,27,12,14,0)),
            new TrainStation("Heiloo",2,new DateTime(2022, 4,27,12,19,0),new DateTime(2022, 4,27,12,19,0)),
            new TrainStation("Castricum",2,new DateTime(2022, 4,27,12,25,0),new DateTime(2022, 4,27,12,25,0)),
            new TrainStation("Zaandam",4,new DateTime(2022, 4,27,12,38,0),new DateTime(2022, 4,27,12,38,0)),
            new TrainStation("Amsterdam Sloterdijk",5,new DateTime(2022, 4,27,12,45,0),new DateTime(2022, 4,27,12,45,0)),
            new TrainStation("Amsterdam Centraal",4,new DateTime(2022, 4,27,12,51,0),new DateTime(2022, 4,27,12,54,0)),
            new TrainStation("Amsterdam Amstel",4,new DateTime(2022, 4,27,13,02,0),new DateTime(2022, 4,27,13,03,0)),
            new TrainStation("Utrecht Centraal",19,new DateTime(2022, 4,27,13,21,0),new DateTime(2022, 4,27,13,23,0)),
            new TrainStation("Driebergen-Zeist",2,new DateTime(2022, 4,27,13,31,0),new DateTime(2022, 4,27,13,31,0)),
            new TrainStation("Ede-Wageningen",4,new DateTime(2022, 4,27,13,47,0),new DateTime(2022, 4,27,13,49,0)),
            new TrainStation("Arnhem Centraal",8,new DateTime(2022, 4,27,13,59,0),new DateTime(2022, 4,27,14,05,0)),
            new TrainStation("Nijmegen",3,new DateTime(2022, 4,27,14,17,0),new DateTime(2022, 4,27,14,17,0))
        };

        public TrainStation currentStation;
        public bool isReturn;

        private List<IStationObserver> stationObservers;

        public ITrainStation CurrentStation { get => currentStation; }
        bool ITrainJourney.IsReturn { get => isReturn; }

        public void NextStation()
        {
            TrainStation nextStation;
            //Return needed?
            if (trainStations.IndexOf(currentStation) == trainStations.Count - 1)
            {
                isReturn = true;
            }
            else if (trainStations.IndexOf(currentStation) == 0)
            {
                isReturn = false;
            }

            if (isReturn)
            {
                nextStation = trainStations[(trainStations.IndexOf(currentStation) - 1)];
            }
            else
            {
                nextStation = trainStations[(trainStations.IndexOf(currentStation) + 1)];
            }
            currentStation = nextStation;
            NotifyStationObserver();
        }

        public TrainJourney()
        {
            stationObservers = new List<IStationObserver>();
            currentStation = trainStations[0];
            isReturn = false;
        }

        public void AddObserver(IStationObserver observer)
        {
            stationObservers.Add(observer);
        }

        public void RemoveObserver(IStationObserver observer)
        {
            stationObservers.Remove(observer);
        }

        private void NotifyStationObserver()
        {
            foreach (IStationObserver observer in stationObservers)
            {
                observer.Update(this.currentStation);
            }
        }
    }
}
