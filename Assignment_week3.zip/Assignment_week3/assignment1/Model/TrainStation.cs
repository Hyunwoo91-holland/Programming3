﻿using System;
using Interfaces;

namespace Model
{
    public class TrainStation : ITrainStation
    {
        public TrainStation(string name, int arrivalTrack,
            DateTime arrivalTime, DateTime departureTime)
        {
            Name = name;
            ArrivalTrack = arrivalTrack;
            ArrivalTime = arrivalTime;
            DepartureTime = departureTime;
        }

        public string Name { get ; set ; }
        public int ArrivalTrack { get ; set ; }
        public DateTime ArrivalTime { get ; set ; }
        public DateTime DepartureTime { get ; set ; }
    }
}
