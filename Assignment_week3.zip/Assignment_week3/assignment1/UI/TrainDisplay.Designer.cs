﻿
namespace Views
{
    partial class TrainDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCurrentStation = new System.Windows.Forms.Label();
            this.lblRail = new System.Windows.Forms.Label();
            this.lblCurrentStationOut = new System.Windows.Forms.Label();
            this.lblRailOut = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblCurrentStation
            // 
            this.lblCurrentStation.AutoSize = true;
            this.lblCurrentStation.Location = new System.Drawing.Point(96, 120);
            this.lblCurrentStation.Name = "lblCurrentStation";
            this.lblCurrentStation.Size = new System.Drawing.Size(178, 32);
            this.lblCurrentStation.TabIndex = 0;
            this.lblCurrentStation.Text = "Current station:";
            // 
            // lblRail
            // 
            this.lblRail.AutoSize = true;
            this.lblRail.Location = new System.Drawing.Point(96, 203);
            this.lblRail.Name = "lblRail";
            this.lblRail.Size = new System.Drawing.Size(159, 32);
            this.lblRail.TabIndex = 1;
            this.lblRail.Text = "Railway Track:";
            // 
            // lblCurrentStationOut
            // 
            this.lblCurrentStationOut.AutoSize = true;
            this.lblCurrentStationOut.Location = new System.Drawing.Point(399, 120);
            this.lblCurrentStationOut.Name = "lblCurrentStationOut";
            this.lblCurrentStationOut.Size = new System.Drawing.Size(29, 32);
            this.lblCurrentStationOut.TabIndex = 2;
            this.lblCurrentStationOut.Text = "...";
            // 
            // lblRailOut
            // 
            this.lblRailOut.AutoSize = true;
            this.lblRailOut.Location = new System.Drawing.Point(399, 203);
            this.lblRailOut.Name = "lblRailOut";
            this.lblRailOut.Size = new System.Drawing.Size(29, 32);
            this.lblRailOut.TabIndex = 3;
            this.lblRailOut.Text = "...";
            // 
            // ViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblRailOut);
            this.Controls.Add(this.lblCurrentStationOut);
            this.Controls.Add(this.lblRail);
            this.Controls.Add(this.lblCurrentStation);
            this.Name = "ViewForm";
            this.Text = "TrainDisplay";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCurrentStation;
        private System.Windows.Forms.Label lblRail;
        private System.Windows.Forms.Label lblCurrentStationOut;
        private System.Windows.Forms.Label lblRailOut;
    }
}