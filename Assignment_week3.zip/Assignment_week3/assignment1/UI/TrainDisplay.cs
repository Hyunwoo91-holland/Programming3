﻿using System.Windows.Forms;
using Interfaces;

namespace Views
{
    public partial class TrainDisplay : Form, IStationObserver
    {
        ITrainJourney journey;

        public TrainDisplay(ITrainJourney journey)
        {
            InitializeComponent();

            this.journey = journey;
            this.journey.AddObserver(this);
        }

        public void Update(ITrainStation trainStation)
        {
            lblCurrentStationOut.Text = trainStation.Name;
            lblRailOut.Text = trainStation.ArrivalTrack.ToString();
        }
    }
}
