﻿
using System.Windows.Forms;
using Interfaces;
using Model;

namespace Views
{
    public partial class StationDisplay : Form, IStationObserver
    {
        TrainJourney journey;

        public StationDisplay(TrainJourney journey)
        {
            InitializeComponent();

            this.journey = journey;
            this.journey.AddObserver(this);
            AddList();
        }

        public void AddList()//make the list
        {
            foreach(TrainStation s in journey.trainStations)
            {
                clbStationList.Items.Add(s.Name, CheckState.Unchecked);
            }

        }

        public void Update(ITrainStation trainStation)//update current station
        {
            if (!journey.isReturn)
            {
                for (int i = 0; i <= journey.trainStations.IndexOf(journey.currentStation); i++)
                {
                    clbStationList.SetItemChecked(i, true);
                }
            }
        }

    }
}
