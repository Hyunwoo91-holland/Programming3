﻿
namespace Views
{
    partial class StationDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clbStationList = new System.Windows.Forms.CheckedListBox();
            this.SuspendLayout();
            // 
            // clbStationList
            // 
            this.clbStationList.FormattingEnabled = true;
            this.clbStationList.Location = new System.Drawing.Point(157, 140);
            this.clbStationList.MinimumSize = new System.Drawing.Size(200, 500);
            this.clbStationList.Name = "clbStationList";
            this.clbStationList.Size = new System.Drawing.Size(482, 688);
            this.clbStationList.TabIndex = 0;
            // 
            // StationDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 884);
            this.Controls.Add(this.clbStationList);
            this.Name = "StationDisplay";
            this.Text = "StationDisplay";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckedListBox clbStationList;
    }
}