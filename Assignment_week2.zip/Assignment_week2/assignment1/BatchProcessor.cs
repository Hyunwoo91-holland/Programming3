﻿using System;
using System.Collections.Generic;

namespace assignment1
{
    public class BatchProcessor
    {
         List<BigDataLoader> bigDataLoaders = new List<BigDataLoader>();

        public void AddBigdataLoader(BigDataLoader bigDataLoader)
        {
            bigDataLoaders.Add(bigDataLoader);
        }

        public void ProcessBatch()
        {

            foreach (BigDataLoader bigDataLoader in bigDataLoaders)
            {
                Console.WriteLine("[ETL-proces started]");
                bigDataLoader.ETL();
                Console.WriteLine("[ETL-proces finished]\n");
            }
        }
    }
}
