﻿using System;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        void Start()
        {
            BatchProcessor batchProcessor = new BatchProcessor();
            batchProcessor.AddBigdataLoader(new CallDataLoader());
            batchProcessor.AddBigdataLoader(new TwitterDataLoader());
            batchProcessor.AddBigdataLoader(new SensorDataLoader());
            batchProcessor.ProcessBatch();
        }
    }
}
