﻿using System;
using Model;
using ReservationSystemLogic;
using System.Collections.Generic;

namespace assignment1
{
    class Program
    {
        static void Main()
        {
            try
            {
                Program myProgram = new Program();
                myProgram.Start();
            }

            catch (Exception e)
            {
                Console.WriteLine($"Error occured: " + e.Message);
            }
            Console.ReadKey();
        }

        void Start()
        {

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("testing CustomerService");
            Console.ResetColor();

            SearchCustomerById();
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("testing BookService");
            Console.ResetColor();

            SearchBooksByAuthor();
            Console.WriteLine();
        }

        private static void SearchBooksByAuthor()
        {
            Console.Write($"Enter name of author: ");
            string author = Console.ReadLine();
            BookService bookService = new BookService();
            List<Book> books = bookService.GetByAuthor(author);
            foreach (Book bo in books)
            {
                Console.WriteLine(bo.ToString());
            }
        }

        private static void SearchCustomerById()
        {
            Console.Write($"Enter customer id: ");
            int customerId = int.Parse(Console.ReadLine());
            CustomerService customerService = new CustomerService();
            Customer customer = customerService.GetById(customerId);
            if (customer != null)
            {
                Console.WriteLine(customer);
            }
            else
            {
                Console.WriteLine($"No customer with id {customerId}");
            }
        }
    }
}
