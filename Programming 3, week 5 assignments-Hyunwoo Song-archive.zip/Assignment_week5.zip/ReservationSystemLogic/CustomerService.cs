﻿using System.Collections.Generic;
using DAL;
using Model;

namespace ReservationSystemLogic
{
    public class CustomerService
    {
        private CustomerDAO customerDAO;

        public CustomerService()
        {
            customerDAO = new CustomerDAO();
        }

        public List<Customer> GetAll()
        {
            return customerDAO.GetAll();
        }

        public Customer GetById(int customerId)
        {
            return customerDAO.GetById(customerId);
        }
    }
}
