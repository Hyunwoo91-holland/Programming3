﻿using System.Collections.Generic;
using DAL;
using Model;

namespace ReservationSystemLogic
{
    public class ReservationService
    {
        private ReservationDAO reservationDAO = new ReservationDAO();

        public List<Reservation> GetAll()
        {
            return reservationDAO.GetAll();
        }

        public Reservation GetById(int reservationId)
        {
            return reservationDAO.GetById(reservationId);
        }

        public List<Customer> getAllForBook(Book book)
        {
            return reservationDAO.getAllForBook(book);
        }

        public List<Book> GetAllForCustomer(Customer customer)
        {
            return reservationDAO.getAllForCustomer(customer);
        }
    }
}

