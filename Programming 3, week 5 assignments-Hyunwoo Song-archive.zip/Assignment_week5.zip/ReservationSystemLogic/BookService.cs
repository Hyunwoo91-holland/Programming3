﻿using System.Collections.Generic;
using DAL;
using Model;

namespace ReservationSystemLogic
{
    public class BookService
    {
        private BookDAO bookDAO = new BookDAO();

        public List<Book> GetAll()
        {
            return bookDAO.GetAll();
        }

        public Book GetById(int bookId)
        {
            return bookDAO.GetById(bookId);
        }

        public List<Book> GetByAuthor(string authorName)
        {
            return bookDAO.GetByAuthor(authorName);
        }
    }
}

