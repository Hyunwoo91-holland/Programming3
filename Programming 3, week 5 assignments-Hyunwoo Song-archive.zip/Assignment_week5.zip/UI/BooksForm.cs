﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using ReservationSystemLogic;
using DAL;
using Model;
using System.Windows.Forms;

namespace UI
{
    public partial class BooksForm : Form
    {
        public BooksForm()
        {
            InitializeComponent();
            DisplayBooks();
            cmbBooks.SelectedIndex = 0;

        }

        private void DisplayBooks()
        {
            BookDAO bookDAO = new BookDAO();
            List<Book> books = bookDAO.GetAll();
            foreach (Book bo in books)
            {
                cmbBooks.Items.Add(bo);
            }
            Controls.Add(cmbBooks);
        }

        private void cmbBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReservationService reservationService = new ReservationService();
            Book selectedBook = (Book)cmbBooks.SelectedItem;
            List<Customer> customers = reservationService.getAllForBook(selectedBook);
            foreach(Customer cust in customers)
            {
                lstReservations.Items.Add(cust.FullName);
            }
        }
    }
}
