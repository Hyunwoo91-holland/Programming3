﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class ReservationSystem : Form
    {
        public ReservationSystem()
        {
            InitializeComponent();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customers customersForm = new Customers();
            customersForm.Show(); // may open multiple window form
        }

        private void booksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BooksForm booksForm = new BooksForm();
            booksForm.ShowDialog();// open only one at once
        }

        private void reservationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReservationForm reservationsForm = new ReservationForm();
            reservationsForm.ShowDialog();
        }
    }
}
