﻿
using System.Collections.Generic;
using System.Windows.Forms;
using ReservationSystemLogic;
using Model;

namespace UI
{
    public partial class ReservationForm : Form
    {
        public ReservationForm()
        {
            InitializeComponent();
            DisplayReservations();
        }

        private void DisplayReservations()
        {
            ReservationService reservationService = new ReservationService();
            List<Reservation> reservations = reservationService.GetAll();

            foreach (Reservation reserv in reservations)
            {
                ListViewItem item = new ListViewItem(reserv.Id.ToString());
                item.SubItems.Add(reserv.Customer.FullName);
                item.SubItems.Add(reserv.Book.ToString());
                lstReservations.Items.Add(item);
            }
        }

    }
}
