﻿
namespace UI
{
    partial class ReservationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstReservations = new System.Windows.Forms.ListView();
            this.Id = new System.Windows.Forms.ColumnHeader();
            this.Customer = new System.Windows.Forms.ColumnHeader();
            this.Book = new System.Windows.Forms.ColumnHeader();
            this.lblReservations = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstReservations
            // 
            this.lstReservations.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Id,
            this.Customer,
            this.Book});
            this.lstReservations.HideSelection = false;
            this.lstReservations.Location = new System.Drawing.Point(33, 142);
            this.lstReservations.MinimumSize = new System.Drawing.Size(1000, 0);
            this.lstReservations.Name = "lstReservations";
            this.lstReservations.Size = new System.Drawing.Size(1100, 250);
            this.lstReservations.TabIndex = 0;
            this.lstReservations.UseCompatibleStateImageBehavior = false;
            this.lstReservations.View = System.Windows.Forms.View.Details;
            // 
            // Id
            // 
            this.Id.Text = "Id";
            this.Id.Width = 80;
            // 
            // Customer
            // 
            this.Customer.Text = "Customer";
            this.Customer.Width = 300;
            // 
            // Book
            // 
            this.Book.Text = "Book";
            this.Book.Width = 500;
            // 
            // lblReservations
            // 
            this.lblReservations.AutoSize = true;
            this.lblReservations.Location = new System.Drawing.Point(33, 87);
            this.lblReservations.Name = "lblReservations";
            this.lblReservations.Size = new System.Drawing.Size(147, 32);
            this.lblReservations.TabIndex = 1;
            this.lblReservations.Text = "Reservations";
            // 
            // ReservationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1174, 429);
            this.Controls.Add(this.lblReservations);
            this.Controls.Add(this.lstReservations);
            this.Name = "ReservationForm";
            this.Text = "Reservations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstReservations;
        private System.Windows.Forms.ColumnHeader Id;
        private System.Windows.Forms.ColumnHeader Customer;
        private System.Windows.Forms.ColumnHeader Book;
        private System.Windows.Forms.Label lblReservations;
    }
}