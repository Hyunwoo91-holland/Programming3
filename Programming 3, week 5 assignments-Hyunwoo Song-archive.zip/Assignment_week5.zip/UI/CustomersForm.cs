﻿using System;
using System.Collections.Generic;
using Model;
using System.Windows.Forms;
using ReservationSystemLogic;
using DAL;

namespace UI
{
    public partial class Customers : Form
    {
        private CustomerService customerService = new CustomerService();

        public Customers()
        {
            InitializeComponent();
            DisplayCustomers();
            cmbCustomers.SelectedIndex = 0;// no selection in properties list
        }

        private void DisplayCustomers()
        {
            List<Customer> customers = customerService.GetAll();
            foreach (Customer cust in customers)
            {
                cmbCustomers.Items.Add(cust);
                //how to add customer without E-mail(ToString)?
            }
            Controls.Add(cmbCustomers);
        }

        private void cmbCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            IstReservations.Items.Clear();
            ReservationService reservationService = new ReservationService();
            Customer customer = (Customer)cmbCustomers.SelectedItem;
            List<Book> books = reservationService.GetAllForCustomer(customer);
            foreach(Book bo in books)
            {
                IstReservations.Items.Add(bo);
            }
        }
    }
}
