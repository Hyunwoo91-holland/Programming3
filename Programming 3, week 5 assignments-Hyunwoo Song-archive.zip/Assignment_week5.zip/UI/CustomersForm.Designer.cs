﻿
namespace UI
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbCustomers = new System.Windows.Forms.ComboBox();
            this.lbl_customer = new System.Windows.Forms.Label();
            this.IstReservations = new System.Windows.Forms.ListBox();
            this.lblReservations = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbCustomers
            // 
            this.cmbCustomers.DropDownWidth = 300;
            this.cmbCustomers.FormattingEnabled = true;
            this.cmbCustomers.Location = new System.Drawing.Point(554, 61);
            this.cmbCustomers.MinimumSize = new System.Drawing.Size(250, 0);
            this.cmbCustomers.Name = "cmbCustomers";
            this.cmbCustomers.Size = new System.Drawing.Size(400, 40);
            this.cmbCustomers.TabIndex = 0;
            this.cmbCustomers.SelectedIndexChanged += new System.EventHandler(this.cmbCustomers_SelectedIndexChanged);
            // 
            // lbl_customer
            // 
            this.lbl_customer.AutoSize = true;
            this.lbl_customer.Location = new System.Drawing.Point(54, 69);
            this.lbl_customer.Name = "lbl_customer";
            this.lbl_customer.Size = new System.Drawing.Size(184, 32);
            this.lbl_customer.TabIndex = 1;
            this.lbl_customer.Text = "Select customer";
            // 
            // IstReservations
            // 
            this.IstReservations.FormattingEnabled = true;
            this.IstReservations.ItemHeight = 32;
            this.IstReservations.Location = new System.Drawing.Point(54, 234);
            this.IstReservations.MinimumSize = new System.Drawing.Size(900, 4);
            this.IstReservations.Name = "IstReservations";
            this.IstReservations.Size = new System.Drawing.Size(900, 164);
            this.IstReservations.TabIndex = 2;
            // 
            // lblReservations
            // 
            this.lblReservations.AutoSize = true;
            this.lblReservations.Location = new System.Drawing.Point(54, 189);
            this.lblReservations.Name = "lblReservations";
            this.lblReservations.Size = new System.Drawing.Size(147, 32);
            this.lblReservations.TabIndex = 3;
            this.lblReservations.Text = "Reservations";
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 450);
            this.Controls.Add(this.lblReservations);
            this.Controls.Add(this.IstReservations);
            this.Controls.Add(this.lbl_customer);
            this.Controls.Add(this.cmbCustomers);
            this.MinimumSize = new System.Drawing.Size(1000, 71);
            this.Name = "Customers";
            this.Text = "Customers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbCustomers;
        private System.Windows.Forms.Label lbl_customer;
        private System.Windows.Forms.ListBox IstReservations;
        private System.Windows.Forms.Label lblReservations;
    }
}