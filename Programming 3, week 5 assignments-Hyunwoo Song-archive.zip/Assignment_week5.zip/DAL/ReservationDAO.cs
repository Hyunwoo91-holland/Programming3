﻿using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using Model;

namespace DAL
{
    public class ReservationDAO
    {
        private SqlConnection dbConnection;
        public ReservationDAO()
        {
            string connString = ConfigurationManager
                                    .ConnectionStrings["DBConnectionString"]
                                    .ConnectionString;
            dbConnection = new SqlConnection(connString);
        }

        public List<Reservation> GetAll()
        {
            dbConnection.Open();
            SqlCommand cmd = new SqlCommand("SELECT Reservations.Id, Reservations.CustomerId, Reservations.BookId," +
                                            "Customers.FirstName, Customers.LastName, Customers.EmailAddress," +
                                            "Books.Title, Books.Author FROM Reservations INNER JOIN Customers " +
                                            "ON Reservations.CustomerId = Customers.Id INNER JOIN Books " +
                                            "On Reservations.BookId = Books.Id", dbConnection);
            SqlDataReader reader = cmd.ExecuteReader();
            List<Reservation> reservations = new List<Reservation>();
            while (reader.Read())
            {
                Reservation reservation = ReadReservation(reader);
                reservations.Add(reservation);
            }
            reader.Close();
            dbConnection.Close();

            return reservations;
        }

        public Reservation GetById(int reservationId)
        {
            dbConnection.Open();
            SqlCommand cmd = new SqlCommand("SELECT Reservations.Id, Reservations.CustomerId, Reservations.BookId," +
                                            "Customers.FirstName, Customers.LastName, Customers.EmailAddress," +
                                            "Books.Title, Books.Author FROM Reservations INNER JOIN Customers " +
                                            "ON Reservations.CustomerId = Customers.Id INNER JOIN Books " +
                                            "On Reservations.BookId = Books.Id WHERE Reservations.Id = @Id", dbConnection);

            cmd.Parameters.AddWithValue("@Id", reservationId);

            SqlDataReader reader = cmd.ExecuteReader();
            Reservation reservation = null;

            if (reader.Read())
            {
                reservation = ReadReservation(reader);
            }
            reader.Close();
            dbConnection.Close();

            return reservation;
        }

        private Reservation ReadReservation(SqlDataReader reader)
        {
            int id = (int)reader["Id"];

            Customer customer = new Customer
                ((int)reader["CustomerId"],
                (string)reader["FirstName"],
                (string)reader["LastName"],
                (string)reader["EmailAddress"]
                );

            Book book = new Book
                ((int)reader["BookId"],
                (string)reader["Title"],
                (string)reader["Author"]
                );

            return new Reservation(id, customer, book);
        }

        public List<Customer> getAllForBook(Book book)
        {
            List<Customer> customers = new List<Customer>();
            dbConnection.Open();
            SqlCommand cmd = new SqlCommand("SELECT Reservations.Id, Reservations.CustomerId, Reservations.BookId," +
                                            "Customers.FirstName, Customers.LastName, Customers.EmailAddress," +
                                            "Books.Title, Books.Author FROM Reservations INNER JOIN Customers " +
                                            "ON Reservations.CustomerId = Customers.Id INNER JOIN Books " +
                                            "On Reservations.BookId = Books.Id WHERE Books.Id = @Id", dbConnection);

            cmd.Parameters.AddWithValue("@Id", book.Id);

            SqlDataReader reader = cmd.ExecuteReader();
            Customer customer = null;

            while (reader.Read())
            {
                CustomerDAO customerDAO = new CustomerDAO();
                customer = customerDAO.ReadCustomer(reader);
                customers.Add(customer);
            }
            reader.Close();
            dbConnection.Close();
            return customers;
        }

        public List<Book> getAllForCustomer(Customer customer)
        {
            List<Book> books = new List<Book>();
            dbConnection.Open();
            SqlCommand cmd = new SqlCommand("SELECT Reservations.Id, Reservations.CustomerId, Reservations.BookId," +
                                            "Customers.FirstName, Customers.LastName, Customers.EmailAddress," +
                                            "Books.Title, Books.Author FROM Reservations INNER JOIN Customers " +
                                            "ON Reservations.CustomerId = Customers.Id INNER JOIN Books " +
                                            "On Reservations.BookId = Books.Id WHERE Customers.Id = @Id", dbConnection);

            cmd.Parameters.AddWithValue("@Id", customer.Id);

            SqlDataReader reader = cmd.ExecuteReader();
            Book book = null;

            while (reader.Read())
            {
                BookDAO bookDAO = new BookDAO();
                book = bookDAO.ReadBook(reader);
                books.Add(book);
            }
            reader.Close();
            dbConnection.Close();
            return books;
        }
    }
}
