﻿namespace Model
{
    public class Reservation
    {
        private int id;
        public int Id { get { return id; } set { id = value; } }

        public string ReservationDateTime { get; set; }
        public Customer Customer { get; set; }
        public Book Book { get; set; }

        public Reservation(int id, Customer customer, Book book)
        {
            Id = id;
            Customer = customer;
            Book = book;
        }

        public override string ToString()
        {
            return $"{Customer} -> {Book}";
        }
    }
}