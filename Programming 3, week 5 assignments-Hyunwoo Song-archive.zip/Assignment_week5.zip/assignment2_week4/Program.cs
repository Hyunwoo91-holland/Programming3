﻿using System;
using System.Collections.Generic;
using DAL;
using Model;

namespace assignment2
{
    class Program
    {
        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        void Start()
        {
            ReservationDAO reservationDAO = new ReservationDAO();
            CustomerDAO customerDAO = new CustomerDAO();


            //PrintReservations();
            //BookDAO bookDAO = new BookDAO();
            //List<Book> books = bookDAO.GetAll();

            //Book book = books[2];
            //List<Customer> customers = reservationDAO.getAllForBook(book);

            //foreach(Customer cust in customers)
            //{
            //    Console.WriteLine(cust);
            //}
            //Console.WriteLine();

            Console.Write($"Enter customer id: ");
            int customerId = int.Parse(Console.ReadLine());

            Customer customer = customerDAO.GetById(customerId);

            if (customer != null)
            {
                Console.WriteLine(customer);
            }
            else
            {
                Console.WriteLine($"No customer with id {customerId}");
            }
            Console.WriteLine($"{customer.FullName} has reservated following book(s) : ");
            List<Book> booksOfTheCustomer = reservationDAO.getAllForCustomer(customer);

            foreach (Book bo in booksOfTheCustomer)
            {
                Console.WriteLine(bo);
            }
        }

        
        void PrintCustomers()
        {
            CustomerDAO customerDAO = new CustomerDAO();

            List<Customer> customers = customerDAO.GetAll();

            foreach (Customer cust in customers)
            {
                Console.WriteLine(cust);
            }
            Console.WriteLine();
            Console.Write($"Enter customer id: ");
            int id = int.Parse(Console.ReadLine());

            Customer customer = customerDAO.GetById(id);

            if (customer != null)
            {
                Console.WriteLine(customer);
            }
            else
            {
                Console.WriteLine($"No customer with id {id}");
            }

            Console.WriteLine();
        }

        void PrintBooks()
        {
            BookDAO bookDAO = new BookDAO();
            List<Book> books = bookDAO.GetAll();

            foreach (Book bo in books)
            {
                Console.WriteLine(bo);
            }
            Console.WriteLine();
            Console.Write($"Enter book id: ");
            int bookId = int.Parse(Console.ReadLine());

            Book book = bookDAO.GetById(bookId);

            if (book != null)
            {
                Console.WriteLine(book);
            }
            else
            {
                Console.WriteLine($"No book with id {bookId}");
            }
        }

        void PrintReservations()
        {
            ReservationDAO reservationDAO = new ReservationDAO();
            List<Reservation> reservations = reservationDAO.GetAll();

            foreach (Reservation reserv in reservations)
            {
                Console.WriteLine(reserv);
            }
            Console.WriteLine();
            Console.Write($"Enter reservation id: ");
            int reservationId = int.Parse(Console.ReadLine());

            Reservation reservation = reservationDAO.GetById(reservationId);

            if (reservation != null)
            {
                Console.WriteLine(reservation);
            }
            else
            {
                Console.WriteLine($"No reservation with id {reservationId}");
            }

            Console.ReadKey();
        }
    }
}