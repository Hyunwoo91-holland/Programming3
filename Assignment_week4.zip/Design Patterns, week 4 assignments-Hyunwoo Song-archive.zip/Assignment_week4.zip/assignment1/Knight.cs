﻿

namespace assignment1
{
    class Knight : Character 
    {
        public Knight()
        {
            Weapon = new SwordBehaviour();
        }
    }
}
