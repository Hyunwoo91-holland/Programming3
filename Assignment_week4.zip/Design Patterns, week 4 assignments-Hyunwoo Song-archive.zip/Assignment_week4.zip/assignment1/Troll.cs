﻿

namespace assignment1
{
    class Troll: Character
    {
        public Troll()
        {
            Weapon = new AxeBehaviour();
        }
    }
}
