﻿

namespace assignment1
{
    class Queen : Character 
    {
        public Queen()
        {
            Weapon = new KnifeBehaviour();
        }
    }
}
