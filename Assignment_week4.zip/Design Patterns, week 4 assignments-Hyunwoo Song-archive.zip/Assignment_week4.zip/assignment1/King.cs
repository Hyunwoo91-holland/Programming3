﻿

namespace assignment1
{
    class King : Character
    {
        public King()
        {
            Weapon = new BowAndArrowBehaviour();
        }
    }
}
